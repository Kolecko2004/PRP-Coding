#include <stdio.h>
#include <stdlib.h>

#define MAXNUM 69
#define MINNUM 3

void house_filling(int row, int column) {
    if ((row + column)% 2 == 0) {
        putchar('o');
    }

    else {
        putchar('*'); 
    }
}

void fence_build(int fence, char one, char two) {
    int line_alternate = (fence % 2 == 0)? 1 : 0;

    for (int i = 0; i < fence; ++i) {
        
        if (line_alternate % 2 == 0) {
            fprintf(stdout, "%c", one);
        }

        else {
            fprintf(stdout, "%c", two);
        }

        ++line_alternate;
    }
}

void print_x_line(int width) {
    for (int i = 0; i < width; ++i) {
        putchar('X');
    }
}

void vertical_line(int height, int width, int fence) {
    for (int i = 0; i < height - 2; ++i) {
        putchar('X');
        for (int j = 0; j < width - 2; ++j ) {
            if (height == width) {
                house_filling(j, i);
            }
            else {
                putchar(' ');
            }
        }
        putchar('X');
        if (height == width && i + fence == height - 1) {
            fence_build(fence, '|', '-');;
        }

        else if (height == width && i + fence > height - 1) {
            fence_build(fence, '|', ' ');
        }
        putchar('\n');
    }
}

void roof(int width) {
    int middle = 1;
    int left = (width - 2 - middle) / 2;
    int levels = (width - 1) / 2;
    
    for (int i = 0; i < levels - 1; ++i) {

        for (int l = 0; l < left; ++l) {
            putchar(' ');
        }

        putchar('X');

        for (int m = 0; m < middle; ++m) {
            putchar(' ');
        }

        fprintf(stdout, "X\n");

        middle += 2;
        left -= 1;
    }
}

void top(int width) {
    for (int i = 0; i < (width / 2); ++i) {
        putchar(' ');
    }
    fprintf(stdout ,"X\n");
}

int in_range(int num){
    if (num < MINNUM || num > MAXNUM) {
        fprintf(stderr, "Error: Vstup mimo interval!\n");
        exit(101);
    }

    return 0;
}

int inputTest(int testNum1, int testNum2, int scanInfo, int fence) {

    if (scanInfo < 1) {
        fprintf(stderr, "Error: Chybny vstup!\n");
        exit(100);
    }

    else if (testNum1 != testNum2 && scanInfo <= 1) {
        fprintf(stderr, "Error: Chybny vstup!\n");
        exit(100);
    }

    in_range(testNum1);
    in_range(testNum2);
    
    if (testNum1 % 2 != 1) {
        fprintf(stderr, "Error: Sirka neni liche cislo!\n");
        exit(102);
    }

    if (testNum1 == testNum2 && (fence >= testNum1 || fence >= testNum2 || fence <= 0) ) {
        fprintf(stderr, "Error: Neplatna velikost plotu!\n");
        exit(103);
    }

    return 0;
}

int main () {
    int width = 0, height = 0, fence = 0, scan1, scan2;

    scan1 = fscanf(stdin, "%d %d", &width, &height);

    if (width != height) {
        inputTest(width, height, scan1, fence);
    }

    else {
        scan2 = fscanf(stdin, "%d", &fence);
        inputTest(width, height, scan2, fence);
    }
    
    top(width);
    roof(width);
    print_x_line(width);
    fprintf(stdout, "\n");
    vertical_line(height, width, fence);
    print_x_line(width);
    if (width == height) {
        fence_build(fence, '|', '-');
        putchar('\n');
    }

    else {
        putchar('\n');
    }
    
    return 0;
}
